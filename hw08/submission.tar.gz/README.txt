World's Hardest Game 

Created By Nandha Sundaravadivel

Instructions
1. Press Enter to start the Game
2. Use the arrow keys to move the character and avoid the moving obstacles
3. Hitting an obstable will increase the number of deaths
4. When you lose, you can press Start to keep playing
5. Press select at any time to reset the Game
6. The point of the game is to have the least amount of deaths