/*
 * Exported with nin10kit v1.8
 * Time-stamp: Monday 04/05/2021, 18:37:44
 * 
 * Image Information
 * -----------------
 * /cs2110/host/hw08/images/Screen Shot 2021-04-05 at 2.15.38 PM.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BACKGROUND_H
#define BACKGROUND_H

extern const unsigned short background[38400];
#define SCREENSHOT20210405AT21538PM_SIZE 76800
#define SCREENSHOT20210405AT21538PM_LENGTH 38400
#define SCREENSHOT20210405AT21538PM_WIDTH 240
#define SCREENSHOT20210405AT21538PM_HEIGHT 160

#endif

