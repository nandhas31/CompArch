/*
 * Exported with nin10kit v1.8
 * Time-stamp: Tuesday 04/06/2021, 00:48:24
 * 
 * Image Information
 * -----------------
 * /cs2110/host/hw08/images/winner.jpeg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINNER_H
#define WINNER_H

extern const unsigned short winner[38400];
#define WINNER_SIZE 76800
#define WINNER_LENGTH 38400
#define WINNER_WIDTH 240
#define WINNER_HEIGHT 160

#endif

