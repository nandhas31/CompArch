/*
 * Exported with nin10kit v1.8
 * Time-stamp: Tuesday 04/06/2021, 00:33:59
 * 
 * Image Information
 * -----------------
 * /cs2110/host/hw08/images/character.png 20@24
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHARACTER_H
#define CHARACTER_H

extern const unsigned short character[480];
#define CHARACTER_SIZE 960
#define CHARACTER_LENGTH 480
#define CHARACTER_WIDTH 20
#define CHARACTER_HEIGHT 24

#endif

