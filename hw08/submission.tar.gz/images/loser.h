/*
 * Exported with nin10kit v1.8
 * Time-stamp: Tuesday 04/06/2021, 00:37:44
 * 
 * Image Information
 * -----------------
 * /cs2110/host/hw08/images/loser.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSER_H
#define LOSER_H

extern const unsigned short loser[38400];
#define LOSER_SIZE 76800
#define LOSER_LENGTH 38400
#define LOSER_WIDTH 240
#define LOSER_HEIGHT 160

#endif

